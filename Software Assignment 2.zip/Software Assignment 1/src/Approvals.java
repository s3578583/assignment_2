

public class Approvals extends AbstractRMITStaff
{
	public Approvals(String staffID,String firstName, String lastName, String address, String email, String phone, int tfn)
	{
		super(staffID,firstName, lastName, address, email, phone, tfn);
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
