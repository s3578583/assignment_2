
public class Budget
{
	private double courseBudget;
	private double staffBudget;
	
	
	public Budget(double courseBudget, double staffBudget)
	{
		
		this.courseBudget = courseBudget;
		this.staffBudget = staffBudget;
	}


	public double getCourseBudget()
	{
		return courseBudget;
	}


	public double getStaffBudget()
	{
		return staffBudget;
	}
	
	
	public void courseTotalBudget() {
		
		
	}
	public void staffTotalBudget() {
		
		
	}
	public void remainingTotalBudget() {
		
		
	}
	
	public boolean finalApproval()
	{
		return true;
		
	}
	public void allocateBudget() {
		
		
	}
	
}
