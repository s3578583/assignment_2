

public class CourseCoordinator extends AbstractRMITStaff
{

	public CourseCoordinator(String staffID, String firstName, String lastName, String address, String email,
			String phone, int tfn)
	{
		super(staffID, firstName, lastName, address, email, phone, tfn);

	}

	
}
