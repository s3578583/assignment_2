
public class Program
{

		private String programName;
		private String programID;
		
		public Program(String programName, String programID)
		{
			
			this.programName = programName;
			this.programID = programID;
		}
		public String getProgramName()
		{
			return programName;
		}
		public String getProgramID()
		{
			return programID;
		}
		
		
}
